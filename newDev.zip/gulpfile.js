'use strict';

global.production = false;
process.env.NODE_ENV = 'development';
require('./gulp');
